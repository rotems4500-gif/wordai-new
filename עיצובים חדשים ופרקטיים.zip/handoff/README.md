# Handoff: מדריך למשתמש חדש (UserGuide carousel)

## סקירה
החלפה של תוכן הטופיק `guideUser` ב-`HelpModal` במדריך חדש — קרוסלת כרטיסיות
אינטראקטיבית (טאבים, חיצים, מקשי ← →, והחלקה/גרירה), בעיצוב עריכותי וב-framer-motion.
נפתח מהריבון: `מדריך → מדריך למשתמש`.

## על קבצי החבילה — חשוב לקרוא
שלא כמו handoff רגיל, **`UserGuide.jsx` כאן הוא קוד React פרודקשן אמיתי** שנכתב כבר
לפי הסטאק והקונבנציות של הריפו (`wordai-new`): React 19, Tailwind v4 עם ה-design tokens
של Wave-A, אייקוני Phosphor (`ph ph-*`), `framer-motion`, וקומפוננטת ה-`Modal`/`Button`
המשותפת מ-`src/components/ui`. אפשר להעתיק אותו כמו שהוא ל-`src/`.

חלק מהקבצים בחבילה הם **לתצוגה מקדימה בלבד** ואסור להעתיק אותם לאפליקציה:
- `preview.html`, `react-shim.js`, `react-dom-shim.js`, `jsx-runtime-shim.js` —
  רתמה עצמאית שטוענת React/Tailwind/framer-motion דרך CDN רק כדי להראות את העיצוב
  מחוץ לריפו. **לא חלק מהמוצר.**

## רמת גמר (Fidelity)
**Hi-fi / פרודקשן.** צבעים, טיפוגרפיה, ריווח, אנימציות והתנהגות סופיים. המטרה: לשלב את
`UserGuide.jsx` בריפו ולחבר אותו ל-`HelpModal` (3 עריכות, ראה למטה). אין צורך "לשחזר" —
רק לשלב ולאמת בסביבה האמיתית.

## איך לשלב (3 עריכות) — מפורט ב-`INTEGRATION.md`
1. העתק `UserGuide.jsx` ל-`src/UserGuide.jsx`.
2. ב-`src/HelpModal.jsx`:
   - `import UserGuide from './UserGuide';`
   - בטופיק `guideUser`: `content: <UserGuide />` + דגל `full: true`.
   - ב-`return`: `size={doc.full ? 'xl' : 'lg'}`, וכש-`doc.full` לעטוף ב-`<div className="-mx-5 -my-4">`
     כדי לבטל את ה-padding של ה-`Modal`.
3. אין שינוי ב-`Ribbon.jsx` / `main.jsx` — הכפתור כבר מפנה לטופיק `guideUser`.

לאימות: `npm run dev`, לפתוח `מדריך → מדריך למשתמש`.

## מבנה הקומפוננטה
- **Shell**: רצועת פתיח ("דני"), שורת טאבים נגללת, אזור קרוסלה, פוטר עם נקודות + מונה.
- **כרטיס (11)**: ספרת ענק דהויה ברקע (watermark), תג אייקון בגרדיאנט, כותרת, lead, ושורת
  "דני אומר", ואז גוף ייחודי לנושא.
- כל 11 הכרטיסים מאוכלסים תמיד (אין lazy-render, אין `AnimatePresence`).

## אינטראקציות והתנהגות
- **ניווט**: טאב (`goTo(i)`), חיצים בצדדים, מקשי `ArrowLeft`=הבא / `ArrowRight`=הקודם (RTL),
  והחלקה אופקית (סף 80px / מהירות).
- **מסילה**: `motion.div` יחיד עם `MotionValue x`, מונע ספרינג (`stiffness 320, damping 32`).
  הרוחב נמדד עם `ResizeObserver`; `x` מונפש אל `-index * vw`.
- **גרירה**: pointer events ידניים עם נעילת ציר (אופקי בלבד; אנכי נשאר לגלילה הפנימית של הכרטיס),
  מעקב-אצבע חי + "התנגדות" (×0.3) בקצוות.
- **חשיפה מדורגת**: כותרת כל כרטיס נכנסת ב-stagger (`staggerChildren .05`, spring rise).
- **ריחוף**: כרטיסי-המשנה מתרוממים `y:-3` בספרינג; חיצים `scale 1.08`, נקודה פעילה מתארכת.

### למה לא AnimatePresence
הניסיון הראשוני (`drag` + `exit` על אותו אלמנט) הקפיא את `AnimatePresence` (הכרטיס לא
מתחלף בזמן שהמונה מתקדם). המנוע הוחלף למסילה אחת מונעת-ספרינג ללא `AnimatePresence` —
יציב ונקי. אל תחזיר `drag`+`exit` לאותו motion element.

## State
- `index` (כרטיס פעיל), `vw` (רוחב viewport מ-`ResizeObserver`), `x` (`useMotionValue`),
  `drag` ref (x/y התחלתי, ציר, active). אין fetching — תוכן סטטי במערכי `const` בראש הקובץ.

## Design tokens (מהריפו, `tailwind.css`)
- `--color-brand #6c5ce7`, `--color-brand-light #a29bfe`, `--color-chrome #2B579A`
- `--color-ink #2d3436`, `--color-muted #636e72`, `--color-page #f8f9fa`, `--color-surface #fff`
- `--color-warn #f59e0b`
- `--radius-control 10px`, `--radius-card 16px`, `--radius-pill 999px`
- גופן `Rubik`. גרדיאנט המותג שחוזר: `linear-gradient(135deg,#6c5ce7,#a29bfe)`.

## נכסים ואייקונים
- אייקוני **Phosphor** בלבד (כבר בשימוש בריפו): `ph-rocket-launch`, `ph-map-trifold`,
  `ph-signpost`, `ph-squares-four`, `ph-plugs-connected`, `ph-sparkle`, `ph-terminal-window`,
  `ph-user-focus`, `ph-list-checks`, `ph-flask`, `ph-lightbulb`, `ph-caret-left/right`,
  `ph-check`, `ph-warning`, ועוד. אין נכסי תמונה.
- "דני" הוא כרגע עיגול עם האות ד׳ בגרדיאנט. אם תרצו דמות מאוירת — זה המקום היחיד להחליף.

## תוכן
כל הטקסט (11 נושאים: מדריך כיס, סיור, ישיר/סביבה, סביבות עבודה, ספקים, חלונית AI, סקילים,
פרופיל, מסלולים, מתקדם, טיפים) נמצא במערכי ה-`const` בראש `UserGuide.jsx` — קל לערוך שם.

## קבצים בחבילה
- `UserGuide.jsx` — **קוד פרודקשן** ← `src/UserGuide.jsx`
- `INTEGRATION.md` — שלושת העריכות ל-`HelpModal.jsx`
- `preview.html` + `*-shim.js` — **תצוגה מקדימה בלבד, לא להעתיק לריפו**

## נקודת פתיחה ל-Claude Code
פתח את Claude Code בריפו `wordai-new` והדבק משהו כמו:
> "צרף את `UserGuide.jsx` ל-`src/`, ובצע את שלוש העריכות מ-`INTEGRATION.md` ב-`src/HelpModal.jsx`
> כך שהטופיק `guideUser` יציג את `<UserGuide/>` במודאל ברוחב `xl`. ודא שהאייקונים והגרדיאנטים
> מתאימים ל-tokens הקיימים, הרץ `npm run dev` ופתח מדריך → מדריך למשתמש."
