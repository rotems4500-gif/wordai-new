// Preview-only shim for the automatic JSX runtime, backed by the page's React.
const R = window.React;
export const Fragment = R.Fragment;
function build(type, config, maybeKey) {
  const props = {};
  let children;
  if (config) {
    for (const k in config) {
      if (k === 'children') children = config[k];
      else props[k] = config[k];
    }
  }
  if (maybeKey !== undefined) props.key = maybeKey;
  if (Array.isArray(children)) return R.createElement(type, props, ...children);
  if (children !== undefined) return R.createElement(type, props, children);
  return R.createElement(type, props);
}
export const jsx = build;
export const jsxs = build;
export const jsxDEV = build;
export default { Fragment, jsx, jsxs, jsxDEV };
