# החלת המדריך החדש על האפליקציה

המדריך החדש מגיע כקומפוננטה אחת עצמאית: **`UserGuide.jsx`**.
היא משתמשת ב-**framer-motion** (כבר מותקן אצלך — `^12.42.0`) לאנימציות, וב-tokens
הקיימים של Tailwind (`bg-brand` / `text-ink` / `text-muted` / `bg-surface` / `bg-page` /
`rounded-card` / `rounded-pill` / `rounded-control` / `text-warn`) ובאייקוני Phosphor
(`ph ph-*`). **אין תלויות חדשות להתקין.**

## צעד 1 — להעתיק את הקובץ
העתק את `UserGuide.jsx` אל `src/UserGuide.jsx`.

## צעד 2 — לחבר ל-HelpModal
ב-`src/HelpModal.jsx` יש שלושה שינויים קטנים:

**א. import בראש הקובץ:**
```jsx
import UserGuide from './UserGuide';
```

**ב. החלף את התוכן של הטופיק `guideUser`** (האובייקט שבתוך `GUIDE_CONTENT`) ב:
```jsx
  guideUser: {
    title: 'מדריך למשתמש',
    full: true,                 // דגל חדש — ראו צעד ג'
    content: <UserGuide />,
  },
```
(שאר הטופיקים — `studios`, `guideAPIKeys`, `shortcuts` וכו' — נשארים בדיוק כפי שהם.)

**ג. תן ל-Modal רוחב מלא רק למדריך** — בתחתית הקומפוננטה, החלף את ה-`return`:
```jsx
  const doc = GUIDE_CONTENT[topic] || GUIDE_CONTENT.about;

  return (
    <Modal
      open={isOpen}
      onClose={onClose}
      title={doc.title}
      size={doc.full ? 'xl' : 'lg'}
      footer={<Button onClick={onClose}>הבנתי, תודה</Button>}
    >
      {doc.full
        ? <div className="-mx-5 -my-4">{doc.content}</div>   {/* מבטל את ה-padding של ה-Modal */}
        : <div className="text-[15px] text-slate-700">{doc.content}</div>}
    </Modal>
  );
```

זהו. הכפתור בריבון (`{ id: 'guideUser', label: 'מדריך למשתמש' }`) כבר פותח את הטופיק הזה,
אז שום שינוי לא נדרש ב-`Ribbon.jsx` או ב-`main.jsx`.

## הערות
- `UserGuide` הוא קרוסלת כרטיסיות: כל נושא הוא כרטיס שמחליפים בטאבים, בחיצים בצדדים,
  במקשי ← →, או בהחלקה/גרירה (RTL). הקומפוננטה תופסת `h-[80vh]` וכל כרטיס גולל אנכית
  בנפרד אם הוא ארוך. ה-`-mx-5 -my-4` מבטל את ריווח ברירת המחדל של ה-Modal.
- אם תרצה למזג גם את הטופיק `studios` (📈📊🎨🧬) לתוך המדריך במקום טאב נפרד —
  הוא כבר מופיע כסקשן "כלים מתקדמים" בתוך `UserGuide`, אז אפשר פשוט להסיר אותו מתפריט
  הריבון. אופציונלי.
- צבעים: הכל נגזר מ-`--color-brand` (#6c5ce7). אם תשנה את ה-token, המדריך מתעדכן איתו.
- האזהרה על `.spv` משתמשת ב-`bg-warn/10` + `text-warn`; אם ה-alpha על token לא פעיל
  אצלך, החלף ל-`bg-amber-50 text-amber-700 border-amber-200`.

## תצוגה מקדימה לפני שמטמיעים
`WordFlow User Guide.dc.html` (בשורש הפרויקט) הוא אותו עיצוב בדיוק כדף עצמאי לגלילה,
עם מתג ערכות נושא — נוח להראות/לאשר לפני ההטמעה בקוד.
