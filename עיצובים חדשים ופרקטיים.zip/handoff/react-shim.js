// Preview-only shim: re-exports the page's UMD React as an ES module so the
// ESM build of framer-motion (loaded with ?external=react) shares one React.
const R = window.React;
export default R;
export const {
  useState, useEffect, useRef, useCallback, useMemo, useContext, useLayoutEffect,
  useId, useReducer, useImperativeHandle, useDebugValue, useTransition, useDeferredValue,
  useSyncExternalStore, forwardRef, createElement, cloneElement, createContext,
  Fragment, Component, PureComponent, memo, Children, isValidElement, createRef, lazy, Suspense, version,
} = R;
export const useInsertionEffect = R.useInsertionEffect || R.useLayoutEffect || R.useEffect;
