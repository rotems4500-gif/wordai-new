// Preview-only shim: re-exports the page's UMD ReactDOM as an ES module.
const RD = window.ReactDOM;
export default RD;
export const createPortal = RD.createPortal;
export const flushSync = RD.flushSync;
export const findDOMNode = RD.findDOMNode;
export const render = RD.render;
export const createRoot = RD.createRoot;
export const version = RD.version;
